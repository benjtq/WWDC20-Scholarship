//:
//: # Basic Shapes
//: On this page you can learn about the simplest waveforms: Sine, Triangle, Square, and Sawtooth.
//: Have fun with the various controls, see how a wave that was once instantly recognisable bewcomes something completely new!
//:
//:
//: All prose written by myself.
//:
//: When you are ready, lets try... [Harmonics](@next)
//:
//: - Note: Please resize the Live View to get the full experience.
//:

import PlaygroundSupport
import SwiftUI


let liveView = NSHostingView(rootView:
    Window(BasicShapesPage())
        .frame(width: 2500, height: 2000)
)

PlaygroundPage.current.liveView = liveView
