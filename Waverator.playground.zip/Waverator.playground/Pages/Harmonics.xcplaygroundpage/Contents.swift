//:
//: # Harmonics
//: On this page you can experiment with combining sine waves to create your own unique signals!
//:
//: Use the first row of sliders to adjust the **levels** of each component sine.
//: Use the second to adjust each wave's **phases**.
//:
//: [Go back to Basic Shapes](@previous)
//:
//: - Note: Please resize the Live View to get the full experience.
//:

import PlaygroundSupport
import SwiftUI

let liveView = NSHostingView(rootView:
    Window(HarmonicsPage(resolution: .large)
        .frame(width: 1000, height: 1000))
)

PlaygroundPage.current.liveView = liveView
