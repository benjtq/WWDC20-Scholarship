import Foundation
import SwiftUI

public struct BasicShapesPage {
    
    static var resolution: DSPLength = .icon
    
//    @State var sine_frequency: UInt = 1
//    @State var sine_phase: DSPFloat = 0.0
//    @State var sine_amplitude: DSPFloat = 1.0
//
//    @State var triangle_frequency: UInt = 1
//    @State var triangle_phase: DSPFloat = 0.0
//    @State var triangle_amplitude: DSPFloat = 1.0
//
//    @State var square_frequency: UInt = 1
//    @State var square_phase: DSPFloat = 0.0
//    @State var square_amplitude: DSPFloat = 1.0
//
//    @State var sawtooth_frequency: UInt = 1
//    @State var sawtooth_phase: DSPFloat = 0.0
//    @State var sawtooth_amplitude: DSPFloat = 1.0

    public init() {}
}


extension BasicShapesPage {
    
    func sine(time: DSPFloat, frequency: UInt, phase: DSPFloat, amplitude: DSPFloat) -> DSPFloat {
        sin(time, freq: frequency, phase: phase) * amplitude
    }
    
    public func square(time: DSPFloat, frequency: UInt, phase: DSPFloat, amplitude: DSPFloat) -> DSPFloat {
        sign(sin(time, freq: frequency, phase: phase)) * amplitude
    }
    
    public func triangle(time: DSPFloat, frequency: UInt, phase: DSPFloat, amplitude: DSPFloat) -> DSPFloat {
        (2 * amplitude / DSPFloat.pi) * asin(Foundation.sin(2 * (DSPFloat.pi / (1 / DSPFloat(frequency))) * (time + phase)))
    }
    
    public func sawtooth(time: DSPFloat, frequency: UInt, phase: DSPFloat, amplitude: DSPFloat) -> DSPFloat {
        let pos = (time + phase)
        return (sign(2 * pos - 1) - 2 * pos + 1) * amplitude
    }
    
}

extension BasicShapesPage: View {
    public var body: some View {
        HStack(alignment: .top, spacing: Self.BLOCK_SPACING) {
            VStack(spacing: Self.BLOCK_SPACING) {
                SignalBlockView("Triangle", function: self.triangle, resolution: Self.resolution)
                SignalInfoView(.sine, height: 420)
            }
            VStack(spacing: Self.BLOCK_SPACING) {
                SignalInfoView(.triangle, height: 280)
                SignalBlockView("Sine", function: self.sine, resolution: Self.resolution)
                SignalBlockView("Square", function: self.square, resolution: Self.resolution)
            }
            VStack(spacing: Self.BLOCK_SPACING) {
                SignalInfoView(.sawtooth, height: 400)
                SignalBlockView("Sawtooth", function: self.sawtooth, resolution: Self.resolution)
                SignalInfoView(.square, height: 270)
            }
        }
    }
}

extension BasicShapesPage {
    public static var BLOCK_SPACING: CGFloat { 10 }
}
