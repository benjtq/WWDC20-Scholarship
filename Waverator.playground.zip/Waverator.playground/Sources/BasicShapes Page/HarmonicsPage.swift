import SwiftUI

public struct HarmonicsPage {
    
    private static var resolution: DSPLength = .default
    
    @State var amplitudes: [DSPFloat]
    @State var phases: [DSPFloat]
    
    @Environment(\.colorScheme) var colourScheme: ColorScheme
    
    public init(resolution: DSPLength) {
        Self.resolution = resolution
        self._amplitudes = .init(initialValue: .init(repeating: 0.0, count: Int(Self.resolution.length / 2)))
        self._phases = .init(initialValue: .init(repeating: 0.0, count: Int(Self.resolution.length / 2)))
    }
}

extension HarmonicsPage: View {
    public var body: some View {
        ZStack {
            self.background
            self.blockView
        }
            .frame(width: 500, height: 400)
    }
    
    private var background: some View {
        Color.windowBackground(mode: self.colourScheme)
            .overlay(RoundedRectangle(cornerRadius: 11, style: .continuous).stroke(Color.accentColor, lineWidth: 7.5))
    }
    
    private var blockView: some View {
        HarmonicsBlockView(amplitudes: self.$amplitudes, phases: self.$phases, resolution: Self.resolution)//.frame(width: 500, height: 650)
            .cornerRadius(11)
    }
}
