import SwiftUI

public struct HarmonicsBlockView {
    
    static public var AMP_S_HEIGHT:     CGFloat { 80 }
    static public var PHASE_S_HEIGHT:   CGFloat { AMP_S_HEIGHT * 0.7 }

    static public var NUMBER_SPACING:   CGFloat { 5 }
    static public var SLIDER_V_SPACING: CGFloat { 3 }
    
    @Binding var amplitudes: [DSPFloat]
    @Binding var phases: [DSPFloat]
    private let resolution: DSPLength
    
    var signal: FFT.Signal {
        FFT.signal(from: self.amplitudes
            .enumerated()
            .map {
                .init(UInt($0.offset + 1), phase: self.phases[$0.offset], amplitude: $0.element)
        }, resolution: self.resolution)
    }
    
    public init(amplitudes: Binding<[DSPFloat]>, phases: Binding<[DSPFloat]>, resolution: DSPLength) {
        self._amplitudes = amplitudes
        self._phases = phases
        self.resolution = resolution
    }
}

extension HarmonicsBlockView: View {
    public var body: some View {
        VStack(alignment: .center) {
            self.slidersView
            self.waveGraph
        }
    }
    
    public var slidersView: some View {
        ScrollView(.horizontal) {
            HStack {
                VStack(alignment: .trailing) {
                    Spacer()
                    Text("Amplitude").bold()
                    Spacer()
                    Text("Phase").bold()
                    Spacer()
                }
                
                ForEach(0 ..< min(self.amplitudes.count, 64)) { index in
                    VStack(spacing: Self.NUMBER_SPACING) {
                        Text(String(index + 1))
                            .font(.system(size: 9, weight: .bold))
                            .foregroundColor(Color.white.opacity(0.7))
                        
                        VStack(spacing: Self.SLIDER_V_SPACING) {
                            VSlider(self.$amplitudes, index: index)
                                .frame(width: VSlider.THUMB_WIDTH, height: Self.AMP_S_HEIGHT)
                            
                            VSlider(self.$phases, index: index)
                                .frame(width: VSlider.THUMB_WIDTH, height: Self.PHASE_S_HEIGHT)
                        }
                    }
                }
            }
                .padding(15)
        }
            .frame(width: 425, height: 200)
    }
    
    public var waveGraph: some View {
        HStack {
            Spacer()
            SignalGraph(signal: Binding(constant: self.signal), width: 400, height: 400, fill: Color.accentColor)
                .frame(width: 400, height: 200)
            Spacer()
        }
    }
}
