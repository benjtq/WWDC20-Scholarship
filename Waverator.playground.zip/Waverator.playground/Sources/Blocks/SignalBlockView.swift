import AppKit
import SwiftUI


public struct SignalBlockView {
    
    @State private var frequency: UInt = 1
    @State private var phase: DSPFloat = 0.0
    @State private var amplitude: DSPFloat = 1.0
    
    var signal: FFT.Signal {
        let step = DSPFloat(1) / DSPFloat(self.resolution.length)
        return stride(from: DSPFloat.zero, to: DSPFloat(1), by: step).map {
            self.function($0, self.frequency, self.phase, self.amplitude)
        }
    }
    
    let title: String
    let function: SignalFunction
    let resolution: DSPLength
    
    @Environment(\.colorScheme) var colourScheme: ColorScheme
    
    public init(_ name: String, function: @escaping SignalFunction, resolution: DSPLength) {
        self.title = name
        self.function = function
        self.resolution = resolution
    }
}

extension SignalBlockView: View {
    
    public var body: some View {
        self.background.overlay(
            VStack(spacing: .zero) {

                self.topHalf
                Spacer()
                self.bottomHalf
            }
                .padding(0)
                .frame(width: Self.BG_WIDTH, height: Self.BG_HEIGHT)
        )
            .frame(width: Self.BG_WIDTH, height: Self.BG_HEIGHT)
    }
    
    private var topHalf: some View {
        VStack(alignment: .leading) {
            self.header.padding([.horizontal, .top], 20)
            self.configRows
                .frame(height: 81)
                .padding([.horizontal], 20)
        }
    }
    
    private var bottomHalf: some View {
        VStack(spacing: .zero) {
            self.divider()
            self.waveBackground.overlay(self.graphContainer)
        }
    }
    
    private var header: some View {
        Text(self.title)
            .font(.system(size: 22, weight: .heavy))
    }
    
    private var configRows: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack {
                _rowTitle("Frequency")
                Spacer()
                SelectorButtons<UInt>((1, "1𝖧𝗓"), (2, "2𝖧𝗓"), (5, "5𝖧𝗓"), updating: self.$frequency, width: 30)
                NumericField<UInt>(self.$frequency, placeholder: "Hz")
                    .frame(width: Self.R_F_WIDTH, alignment: .leading)
            }
            
            HStack {
                _rowTitle("Phase")
                Spacer()
                SelectorButtons<DSPFloat>((0.0, "0"), (0.25, "¼"), (0.5, "½"), updating: self.$phase, width: 30)
                NumericField<DSPFloat>(self.$phase, placeholder: "float", upperBound: 100.0, shiftBy: 2, unit: "%")
                    .frame(width: Self.R_F_WIDTH, alignment: .leading)
            }
            
            HStack {
                _rowTitle("Amplitude")
                Spacer()
//                SelectorButtons<DSPFloat>(0.1, 0.5, 1.0, max: 1.0, updating: self.$amplitude, width: 30)
                HSlider(self.$amplitude)
                NumericField<DSPFloat>(self.$amplitude, placeholder: "float", upperBound: 100.0, shiftBy: 2, unit: "%")
                    .frame(width: Self.R_F_WIDTH, alignment: .leading)
            }
            
        }
    }
    
    private func divider() -> some View {
        Rectangle()
            .frame(width: Self.BG_WIDTH - 4, height: 2)
            .foregroundColor(Color(.textColor).opacity(0.15))
    }
    
    private func _rowTitle(_ text: String) -> some View {
        Text(text)
            .multilineTextAlignment(.leading)
            .font(.system(size: 15))
            .frame(width: 75, alignment: .leading)
    }
    
    private var waveBackground: some View {
        RoundedRect(.bottomLeft, .bottomRight, cornerRadius: 11)
            .fill(Color.secondaryBackground(mode: self.colourScheme))
            .frame(width: 246, height: 115)
            .padding(.bottom, 2)
    }
    
    private var graph: some View {
        SignalGraph(
            signal: Binding(constant: self.signal),
            width: Self.WAVE_WIDTH,
            height: Self.WAVE_HEIGHT,
            fill: Color.accentColor
        )
            .animation(.default)
            .frame(width: Self.WAVE_WIDTH, height: Self.WAVE_HEIGHT / 2)
            .padding(0)
    }
    
    private var graphContainer: some View {
        HStack {
            Spacer()
            self.graph.frame(width: Self.WAVE_WIDTH, height: Self.WAVE_HEIGHT)
            Spacer()
        }
    }
    
    private var background: some View {
        
        let bg = Color.windowBackground(mode: self.colourScheme)
        return ZStack {
            bg.cornerRadius(11)
                .frame(width: Self.BG_WIDTH, height: Self.BG_HEIGHT)
            bg
                .cornerRadius(11)
                .overlay(RoundedRectangle(cornerRadius: 11)
                    .stroke(Color(.textColor).opacity(0.15), lineWidth: 2)
            ).frame(width: Self.BG_WIDTH - 2, height: Self.BG_HEIGHT - 2)
        }
    }
}

extension SignalBlockView {
    public static let WAVE_WIDTH:  CGFloat = 190
    public static let WAVE_HEIGHT: CGFloat = 140
    public static let BG_WIDTH:    CGFloat = 250
    public static let BG_HEIGHT:   CGFloat = 300
    public static let R_F_WIDTH:   CGFloat = 50
}

/* If Swift wouldn't give me an annoying warning I would keep this as fileprivate */ extension NSTextField {
    open override var focusRingType: NSFocusRingType {
        get { .none }
        set { }
    }
}
