import SwiftUI

public struct SignalInfoView {
    
    @Environment(\.colorScheme) var colourScheme: ColorScheme
    
    let title: AdditiveText
    let description: AdditiveText
    let functions: [String : String]
    let height: CGFloat
    
    public enum Signal: String {
        case sine = "Sine"
        case triangle = "Triangle"
        case square = "Square"
        case sawtooth = "Sawtooth"
    }
    
    
    init(_ signal: Signal, height: CGFloat) {
        
        let lookup: [Signal : (phrase: String, description: AdditiveText, functions: [String : String])] = [
            .sine: (
                phrase: "Sonic building blocks.",
                description: AdditiveText(.italic("Sine Waves"), " are the purest signal – a smooth, mesmerising oscillation which produces only a single harmonic; the ", .bold("Fundamental Frequency"), ".", "\nFor this reason, they are extremely useful in additive synthesis — imagine a fresh canvas, ready to hold the fruits of your sonic inspiration.\n\n", .bold("Sine Waves in the Real World"), ":\nTheir capability to oscillate in the same smooth manner makes Human vocal cords very capable of producing a sound not unlike a sine wave."),
                functions: ["Sine Function" : "sin(2π𝑥) · 𝑎"]),
            .triangle: (
                phrase: "Not a Sine, not a Square.",
                description: AdditiveText(.italic("Triangle Waves"), " produce the same ", .bold("odd harmonics"), " as square waves.\nHowever, the amplitude of each harmonic drops off far sharper than those of the squares, resulting in the same 'hollow'-sounding acoustics but with the signature sine-wave low end boom."),
                functions: ["Triangle Function" : "2𝑎 ÷ π · asin(sin(2(π ÷ (1 ÷ 𝑓)) · 𝑥))"]),
            .square: (
                phrase: "The binary waveforms",
                description: AdditiveText("An ideal ", .italic("Square Wave"), " switches instantaneously between its high and low phases. \nThis wave's signature square shape is synthesised by combining only the ", .bold("odd"), " sine harmonics; in other words the 1st, 3rd, 5th… ∞ harmonics."),
                functions: ["Square Function" : "sign(sin(𝑥𝑓)) · 𝑎"]),
            .sawtooth: (
                phrase: "The waveforms of the real world.",
                description: AdditiveText("The power of a ", .italic("Sawtooth Wave"), " lies in its harmonics – or rather, the sheer quantity of them. The ideal Sawtooth wave produces ", .bold("all"), " harmonics – every integer multiple of the fundamental frequency.\n\nReal world sounds also usually produce many many harmonics — which is why sawtooths are paired perfectly with the task of producing rich and authentic sonic textures."),
                functions: ["Ramp Function" : "𝑦 = 𝑥", "'Thunderbolt' Function" : "𝑦 = (sign(2𝑥 - 1) - 2𝑥 + 1) · 𝑎"])
        ]
        
        let info = lookup[signal]!
        
        self.title = AdditiveText(.accented(signal.rawValue + " Waves"), .regular(" — " + info.phrase))
        self.description = info.description
        self.functions = info.functions
        
        self.height = height
    }
    
}

extension SignalInfoView: View {
    
    public var body: some View {
        
        self.background.overlay(
            VStack(alignment: .leading) {
                self.title_v(for: self.title)
                    .padding(.bottom, 12)
                
                self.description_v(for: self.description)
                    .padding(.bottom)
                
                self.functions_v
            }
                .padding(.horizontal, 18)
                .padding(.vertical, 16)
        )
            .frame(width: Self.BG_WIDTH, height: self.height, alignment: .top)
    }
    
    private var background: some View {
        
        let bg = Color.windowBackground(mode: self.colourScheme)
        let radius: CGFloat = 10
        
        return ZStack {
            bg.cornerRadius(11)
                .frame(width: Self.BG_WIDTH, height: self.height)
            bg.cornerRadius(radius)
                .overlay(RoundedRectangle(cornerRadius: radius)
                    .stroke(Color.black.opacity(0.3), lineWidth: 2)
            ).frame(width: Self.BG_WIDTH - 2, height: self.height - 2)
        }
    }
    
    private func title_v(for title: AdditiveText) -> some View {
        title.font(.system(size: 14, weight: .bold))
    }
    
    private func description_v(for description: AdditiveText) -> some View {
        description
            .font(.system(size: 12))
            .lineSpacing(2)
            .opacity(0.7)
    }
    
    private var functions_v: some View {
        let headings = Array(self.functions.keys)
        let functions = Array(self.functions.values)
        
        return VStack(alignment: .leading) {
            ForEach(0 ..< functions.count) { f_index in
                
                VStack(alignment: .leading) {
                    self._function_heading_v(for: headings[f_index])
                    self._function_v(for: functions[f_index])
                }
            }
        }
    }
    
    private func _function_heading_v(for function: String) -> some View {
        Text(function.uppercased())
            .foregroundColor(.accentColor)
            .font(.system(size: 11, weight: .bold))
            .kerning(0.3)
            .opacity(0.9)
    }
    
    private func _function_v(for function: String) -> some View {
        
        let text = Text(function)
            .font(.system(size: 12))
            .italic()
            .opacity(0.7)
            .padding(.vertical, 4)
            .padding(.leading, 10)
        
        let bg = self.colourScheme == .dark ? Color(hex: 0x222222) : Color(hex: 0xEFEFF1) //FEFEFE
        
        return ZStack(alignment: .leading) {
            ZStack(alignment: .center) {
                bg.cornerRadius(4)
                    .frame(width: 215, height: 25)
                bg.cornerRadius(4)
                    .overlay(RoundedRectangle(cornerRadius: 4)
                        .stroke(Color.black.opacity(0.3), lineWidth: 2)
                ).frame(width: 215 - 2, height: 25 - 2)
            }
            text
        }
        
    }
}


extension SignalInfoView {
    public static var BG_WIDTH: CGFloat { SignalBlockView.BG_WIDTH }
    public static var BG_HEIGHT: CGFloat { 350 }
}
