import SwiftUI

extension LinearGradient {
    static fileprivate let _soundWave = Gradient(colors: [
//        Color(hex: 0xb3ffab)!,
//        Color(hex: 0x12fff7)!//,
//        Color(hex: 0xb2fefa)!,
//        Color(hex: 0x0ed2f7)!

        Color(hex: 0x7F_FF9300)!,
        Color(hex: 0x7F_FFC500)!,
        Color(hex: 0x7F_FF9300)!
        //          Color(#colorLiteral(red: 0.8549019607843137, green: 0.25098039215686274, blue: 0.47843137254901963, alpha: 1.0)),
        //          Color(#colorLiteral(red: 0.23921568627450981, green: 0.6745098039215687, blue: 0.9686274509803922, alpha: 1.0))
    ])
    
    static public let soundWave = LinearGradient(gradient: LinearGradient._soundWave, startPoint: .top, endPoint: .bottom)
//    static public let soundWave = backgroundGradient
    
}

extension Color {
    static public func windowBackground(mode: ColorScheme) -> Color { mode == .light ? .white : Color(hex: 0x2d2d2d)! }
    static public func secondaryBackground(mode: ColorScheme) -> Color { mode == .dark ? Color(hex: 0x131415)! : Color(hex: 0xEFEFF1)! }
}

/// Hexadecimal base
public let RADIX_HEX: Int = 16

extension Color {
    
    public init?(hex: Int) {
        
        let hex = String(hex, radix: RADIX_HEX)
        
        var chars = Array(hex)
        
        switch chars.count {
        case 3:
            chars = chars.flatMap { [$0, $0] }
            fallthrough
        case 6:
            chars = ["F","F"] + chars
        case 8: break
        default: return nil
        }
        
        let decimal: (ArraySlice<Character>) -> Double = { chars in
            .init(strtoul(String(chars), nil, Int32(RADIX_HEX))) / 255
        }
        
        self.init(
            red: decimal(chars[2...3]),
            green: decimal(chars[4...5]),
            blue: decimal(chars[6...7]),
            opacity: decimal(chars[0...1])
        )
    }
}


