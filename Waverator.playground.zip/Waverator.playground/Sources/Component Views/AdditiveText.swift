import SwiftUI

public struct AdditiveText {
    
    private let styles: [Style]
    
    public enum Style {
        case regular(_ text: String)
        case bold(_ text: String)
        case italic(_ text: String)
        case accented(_ text: String)
        
        var text: String {
            switch self {
            case .bold(let text), .italic(let text), .regular(let text), .accented(let text):
                return text
            }
        }
    }
    
    public init(_ styles: Style...) {
        self.styles = styles
    }
}

extension AdditiveText: View {
    public var body: some View {
        self.styles.map { style in
            
            switch style {
                
            case .accented(let text):
                return Text(text).foregroundColor(.accentColor)
                
            case .bold(let text):
                return Text(text).fontWeight(.bold)
            case .italic(let text):
                return Text(text).italic()
            case .regular(let text):
                return Text(text)
            }
        }
            .reduce(Text(""), +)
    }
}

extension AdditiveText.Style: ExpressibleByStringLiteral {
    public init(stringLiteral text: String) {
        self = .regular(text)
    }
}
