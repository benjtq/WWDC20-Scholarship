import SwiftUI

public struct HSlider: View {
    
    public static var THUMB_WIDTH: CGFloat { 25 }
    
    @Binding private var value: DSPFloat
    
    public init(_ value: Binding<DSPFloat>) {
        self._value = value
    }
    
    public var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                self.track
                self.thumb
                    .offset(x: self.thumbOffset(width: geo.size.width))
                    .animation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0))
            }
        }
    }
    
    private func thumbOffset(width: CGFloat) -> CGFloat {
        CGFloat(self.value) * (width - Self.THUMB_WIDTH)
    }
    
    private var track: some View {
        GeometryReader { geo in
            Rectangle()
                .foregroundColor(Color.accentColor.opacity(0.5))
                .cornerRadius(.infinity)
                .frame(height: 7.5)
                .gesture(DragGesture(minimumDistance: 1.0).onChanged { val in
                    let clampedValue = min(max(DSPFloat(val.location.x / geo.size.width), 0.0), 1.0)
                    let decimalMultiplier = DSPFloat(pow(10.0, 2 /* <—— Number of places */))
                    self.value = DSPFloat(Int(clampedValue * decimalMultiplier)) / decimalMultiplier
                })
        }
    }
    
    private var thumb: some View {
        Rectangle()
            .foregroundColor(.accentColor)
            .cornerRadius(4)
            .frame(width: Self.THUMB_WIDTH)
            .allowsHitTesting(false)
    }
    
}
