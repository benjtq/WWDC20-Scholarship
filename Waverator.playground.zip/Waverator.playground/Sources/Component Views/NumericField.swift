import SwiftUI

public struct NumericField<Number: LosslessStringConvertible & Comparable & Numeric>: View {
    
    @Binding private var value: Number
    private let placeholder: String
    private let upperBound: Double
    private let multiplier: Double
    private let unit: String
    
    public init(_ v: Binding<Number>, placeholder: String, upperBound: Double = 1.0, shiftBy shift: Int = 0, unit: String = "") {
        self._value = v
        self.placeholder = placeholder
        self.upperBound = upperBound
        self.multiplier = pow(10.0, Double(shift))
        self.unit = unit
    }
    
    public var body: some View {
        Text(String(Int(Double(String(self.value))! * self.multiplier)) + self.unit)
            .foregroundColor(.gray)
            .multilineTextAlignment(.leading)
            .frame(alignment: .leading)
    }
    
}
