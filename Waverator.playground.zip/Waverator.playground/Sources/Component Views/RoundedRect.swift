import SwiftUI

public struct RoundedRect: Shape {
    
    public enum Corner {
        case topLeft, topRight
        case bottomLeft, bottomRight
    }
    
    let corners: [Corner]
    let cornerRadius: CGFloat
    
    public init(_ corners: Corner..., cornerRadius: CGFloat) {
        self.corners = corners
        self.cornerRadius = cornerRadius
    }
    
    private func radius(for corner: Corner) -> CGFloat {
        self.corners.contains(corner) ? self.cornerRadius : 0
    }

    public func path(in rect: CGRect) -> Path {
        var path = Path()

        let w = rect.size.width
        let h = rect.size.height

        // Make sure we do not exceed the size of the rectangle
        let tr = min(min(self.radius(for: .topRight), h/2), w/2)
        let tl = min(min(self.radius(for: .topLeft), h/2), w/2)
        let bl = min(min(self.radius(for: .bottomLeft), h/2), w/2)
        let br = min(min(self.radius(for: .bottomRight), h/2), w/2)

        path.move(to: CGPoint(x: w / 2.0, y: 0))
        path.addLine(to: CGPoint(x: w - tr, y: 0))
        path.addArc(center: CGPoint(x: w - tr, y: tr), radius: tr,
                    startAngle: Angle(degrees: -90), endAngle: Angle(degrees: 0), clockwise: false)

        path.addLine(to: CGPoint(x: w, y: h - br))
        path.addArc(center: CGPoint(x: w - br, y: h - br), radius: br,
                    startAngle: Angle(degrees: 0), endAngle: Angle(degrees: 90), clockwise: false)

        path.addLine(to: CGPoint(x: bl, y: h))
        path.addArc(center: CGPoint(x: bl, y: h - bl), radius: bl,
                    startAngle: Angle(degrees: 90), endAngle: Angle(degrees: 180), clockwise: false)

        path.addLine(to: CGPoint(x: 0, y: tl))
        path.addArc(center: CGPoint(x: tl, y: tl), radius: tl,
                    startAngle: Angle(degrees: 180), endAngle: Angle(degrees: 270), clockwise: false)

        return path
    }
}
