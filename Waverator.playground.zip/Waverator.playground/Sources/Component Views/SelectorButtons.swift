import SwiftUI

public struct SelectorButtons<T: LosslessStringConvertible & Equatable & Comparable>: View {
    
    @Environment(\.colorScheme) var colourScheme: ColorScheme
       
    @Binding var selected: T
    let values: [(T, String)]
    let max: T?
    let width: CGFloat
    
    public init(_ values: (T, String)..., max: T? = nil, updating selected: Binding<T>, width: CGFloat) {
        self._selected = selected
        self.max = max
        self.values = values
        self.width = width
    }
    
    public var body: some View {
        
        return ZStack(alignment: .leading) {
            
            self.indicator
            
            HStack(spacing: .zero) {
                
                ForEach(0 ..< self.values.count) { v_index in
                    self.button(for: self.values[v_index])
                }
            }
        }
    }
    
    private var indicator: some View {
        
        guard let offset = self.indicatorOffset else { return AnyView(EmptyView()) }
        
        return AnyView(RoundedRectangle(cornerRadius: 4, style: .continuous)
            .foregroundColor(.accentColor)
            .frame(width: self.width)
            .offset(x: offset)
            .animation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0)))
    }
    
    private func button(for value: (T, String)) -> some View {
        
        var textColour: Color
        if self.colourScheme == .dark {
            textColour = self.selected == value.0 ? .windowBackground(mode: self.colourScheme) : Color.accentColor
        } else {
            textColour = self.selected == value.0 ? .white : Color.black.opacity(0.7)
        }
        
        return Button(action: {
            withAnimation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0)) {
                self.selected = min(value.0, self.max ?? value.0)
            }
        }) {
            Text(value.1)
                .font(.system(size: 13, weight: .semibold))
                .foregroundColor(textColour)
                .frame(width: self.width)
        }
            .buttonStyle(PlainButtonStyle())
        
    }
    
    var indicatorOffset: CGFloat? {
        guard let index = self.values.map(\.0).firstIndex(of: self.selected) else {
            return nil
        }
        return CGFloat(index) * self.width
    }
    
}
