import Foundation // truncf
import SwiftUI

//public struct VSlider: View {
//
//    public static var THUMB_HEIGHT: CGFloat { 15 }
//    public static var THUMB_WIDTH:  CGFloat { 20 }
//
//    @State private var tempValue: DSPFloat
//    @State private var value: DSPFloat
//
//    private let onGestureEnd: SignalRecomputation
//    private let harmonic: UInt
//    private let type: Int8
//
//    public init(_ value: Binding<DSPFloat>, onGestureEnd: @escaping SignalRecomputation, harmonic: UInt, type: Int8) {
//        self._value = .init(initialValue: value.wrappedValue)//value
//        self._tempValue = .init(initialValue: value.wrappedValue)
//        self.onGestureEnd = onGestureEnd
//
//        self.harmonic = harmonic
//        self.type = type
//    }
//
//    public var body: some View {
//        GeometryReader { geo in
//            ZStack(alignment: .top) {
//                self.track(height: geo.size.height)
//                self.thumb(trackHeight: geo.size.height)
//                    .offset(y: self.thumbOffset(height: geo.size.height))
//                    .animation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0))
//            }
//        }
//    }
//
//    private func thumbOffset(height: CGFloat) -> CGFloat {
//        let reverseOffset = CGFloat(self.tempValue) * (height - Self.THUMB_HEIGHT)
//        return height - Self.THUMB_HEIGHT - reverseOffset
//    }
//
//    private func track(height: CGFloat) -> some View {
//        Rectangle()
//            .foregroundColor(Color.accentColor.opacity(0.5))
//            .cornerRadius(.infinity)
//            .frame(width: 7.5)
////            .gesture(self.dragGesture(trackHeight: height))
//        .gesture(DragGesture(minimumDistance: 1.0).onChanged { val in
//                    let clampedValue = min(max(DSPFloat(val.location.y / height), 0.0), 1.0)
//        //            let decimalMultiplier = DSPFloat(pow(10.0, 2 /* <—— Number of places */))
//                    self.tempValue = 1 - clampedValue//(DSPFloat(Int(clampedValue * decimalMultiplier)) / decimalMultiplier)
//                }.onEnded { _ in
//                    print("before:", self.value)
//                    self.value = self.tempValue
//                    print("after:", self.value)
//                    self.onGestureEnd(self.harmonic, self.type, self.value)
//                })
//    }
//
//    private func dragGesture(trackHeight: CGFloat) -> some Gesture {
//        DragGesture(minimumDistance: 1.0).onChanged { val in
//            let clampedValue = min(max(DSPFloat(val.location.y / trackHeight), 0.0), 1.0)
////            let decimalMultiplier = DSPFloat(pow(10.0, 2 /* <—— Number of places */))
//            self.tempValue = 1 - clampedValue//(DSPFloat(Int(clampedValue * decimalMultiplier)) / decimalMultiplier)
//        }.onEnded { _ in
//            print("before:", self.value)
//            self.value = self.tempValue
//            print("after:", self.value)
//            self.onGestureEnd(self.harmonic, self.type, self.value)
//        }
//    }
//
//    private func thumb(trackHeight: CGFloat) -> some View {
//        Rectangle()
//            .foregroundColor(.accentColor)
//            .cornerRadius(4)
//            .frame(width: Self.THUMB_WIDTH, height: Self.THUMB_HEIGHT)
//            .overlay(
//                Text(String(Int(truncf(self.tempValue * 100))))
//                    .font(.system(size: 8, weight: .semibold))
//                    .foregroundColor(Color.white.opacity(0.8))
//                    .frame(width: Self.THUMB_WIDTH)
//        )
//            .allowsHitTesting(false)
//    }
//
//}


public struct VSlider: View {

    public static var THUMB_HEIGHT: CGFloat { 15 }
    public static var THUMB_WIDTH:  CGFloat { 20 }

    @State private var tempValue: DSPFloat
    @Binding var values: [DSPFloat]
    private var index: Int

    public init(_ values: Binding<[DSPFloat]>, index: Int) {
        self._values = values
        self._tempValue = .init(initialValue: values.wrappedValue[index])
        self.index = index
    }

    public var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .top) {
                self.track(height: geo.size.height)
                self.thumb(trackHeight: geo.size.height)
                    .offset(y: self.thumbOffset(height: geo.size.height))
                    .animation(.spring(response: 0.3, dampingFraction: 1, blendDuration: 0))
            }
        }
    }

    private func thumbOffset(height: CGFloat) -> CGFloat {
        let reverseOffset = CGFloat(self.tempValue) * (height - Self.THUMB_HEIGHT)
        return height - Self.THUMB_HEIGHT - reverseOffset
    }

    private func track(height: CGFloat) -> some View {
        Rectangle()
            .foregroundColor(Color.accentColor.opacity(0.5))
            .cornerRadius(.infinity)
            .frame(width: 7.5)
//            .gesture(self.dragGesture(trackHeight: height))
             .gesture(DragGesture(minimumDistance: 1.0).onChanged { val in
                let clampedValue = min(max(DSPFloat(val.location.y / height), 0.0), 1.0)
                self.tempValue = 1 - clampedValue
                self.values[self.index] = self.tempValue
             }.onEnded { _ in
//                self.values[self.index] = self.tempValue
            })
    }


    private func thumb(trackHeight: CGFloat) -> some View {
        Rectangle()
            .foregroundColor(.accentColor)
            .cornerRadius(4)
            .frame(width: Self.THUMB_WIDTH, height: Self.THUMB_HEIGHT)
            .overlay(
                Text(String(Int(truncf(self.tempValue * 100))))
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundColor(Color.white.opacity(0.8))
                    .frame(width: Self.THUMB_WIDTH)
        )
            .allowsHitTesting(false)
    }

}
