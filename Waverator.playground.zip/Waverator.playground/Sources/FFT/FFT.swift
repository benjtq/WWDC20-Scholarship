import Accelerate

public struct FFT {
    
    public struct Harmonic {

        public static let zero = Harmonic(0)
        public static let sine = Harmonic(1)

        public var harmonic: UInt
        public var phase: DSPFloat
        public var amplitude: DSPFloat

        public init(_ harmonic: UInt, phase: DSPFloat = 0.0, amplitude: DSPFloat = 1.0) {
            self.harmonic = harmonic
            self.phase = phase
            self.amplitude = amplitude
        }
    }
    
//    public typealias Harmonic = (UInt, phase: DSPFloat, amplitude: DSPFloat)
    
//    static public func harmonic(_ multiple: UInt, phase: Float = 0.0, amplitude: Float = 1.0) -> FFT.Harmonic {
//        (multiple, phase: phase, amplitude: amplitude)
//    }
    
}

public enum DSPLength: vDSP_Length {
    case `default` = 0
    case _debug    = 5
    case _graphic  = 14
    
    case icon      = 10
    case large     = 12

    public var length: vDSP_Length {
        return UInt(pow(2.0, Double(self.rawValue)))
    }
}
