import Foundation

extension FFT {
    
    public typealias Signal = [Float]
    
    static public func signal(from frequencies: [Harmonic], resolution: DSPLength) -> Signal {
        
        let nonzeroHarmonics = frequencies.filter {
            $0.amplitude != 0 && $0.harmonic != 0
        }
        let gain = 1.0 / Float(nonzeroHarmonics.count)
        
        return (0 ... resolution.length).map { sample in
            nonzeroHarmonics.reduce(0) { acc, harmonic in
                
//                let (freq, phase, amp) = harmonic
                
                let time = Float(sample) / Float(resolution.length)
                let pos = sin(time, freq: harmonic.harmonic, phase: harmonic.phase)
                
                return Float(acc) + sin(pos) * harmonic.amplitude * gain
            }
        }
    }
}


public typealias DSPFloat = FFT.Signal.Element
public typealias SignalFunction = (DSPFloat, UInt, DSPFloat, DSPFloat) -> DSPFloat
