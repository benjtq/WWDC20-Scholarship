import Foundation

public func sin(_ time: DSPFloat, freq: UInt, phase: DSPFloat) -> DSPFloat {
    return Foundation.sin(1
        * (time + phase)
        * DSPFloat.pi
        * 2 * DSPFloat(freq)
    )
//        let phaseOffset = phase * 1//.0477
//
//        return Foundation.sin(1
//        * (time
//        * DSPFloat(freq)
//        * DSPFloat.pi
//        + phaseOffset)
//        * 2.0
//        + phaseOffset) * amp
}

public func sign<Number: SignedNumeric>(_ x: Number) -> Number where Number: Comparable {
    let int: Int64 = x >= .zero ? 1 : -1
    return Number(integerLiteral: int as! Number.IntegerLiteralType)
}
