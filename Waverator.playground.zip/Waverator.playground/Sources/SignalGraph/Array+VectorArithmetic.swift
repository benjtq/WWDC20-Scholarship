import SwiftUI

extension Array: VectorArithmetic, AdditiveArithmetic where Element == DSPFloat {
    
    static public let zero: Self = []
    public var magnitudeSquared: Double {
        Double(self.map { pow($0, 2) }.reduce(0, +))
    }
    
    static public func +(_ lhs: Self, _ rhs: Self) -> Self {
        lhs.enumerated()
            .map {
                $0.element + rhs[safe: $0.offset, or: 0]
            }
    }
    
    static public func +=(_ lhs: inout Self, _ rhs: Self) {
        lhs = lhs + rhs
    }
    
    static public func -(_ lhs: Self, _ rhs: Self) -> Self {
        lhs.enumerated()
            .map {
                $0.element - rhs[safe: $0.offset, or: 0]
        }
    }
    
    static public func -=(_ lhs: inout Self, _ rhs: Self) {
        lhs = lhs - rhs
    }
    
    mutating public func scale(by rhs: Double) {
        self = self.map { $0 * Float(rhs) }
    }
}

extension Array {
    public subscript(safe index: Index, or default: Element) -> Element {
        guard self.indices.contains(index) else { return `default` }
        return self[index]
    }
}
