//import SwiftUI
//
//public struct MultiSignalGraph<Fill: ShapeStyle> {
//    
//    private var functions: [(DSPFloat) -> DSPFloat]
//    private var resolution: DSPLength
//    private let fill: Fill
//    private let lineWidth: CGFloat
//    private let signalSpacing: CGFloat
//    
//    public init(functions: [(DSPFloat) -> DSPFloat], resolution: DSPLength, fill: Fill, lineWidth: CGFloat = 10, signalSpacing: CGFloat = 100) {
//        self.functions = functions
//        self.resolution = resolution
//        self.fill = fill
//        self.lineWidth = lineWidth
//        self.signalSpacing = signalSpacing
//    }
//    
//    func signals() -> [FFT.Signal] {
//        functions.map { function in
//            stride(from: DSPFloat.zero, to: DSPFloat(1), by: DSPFloat(1) / DSPFloat(resolution.length)).map {
//                function($0)
//            }
//        }
//    }
//}
//
//extension MultiSignalGraph: View {
//    
//    public var body: some View {
//        _Graph(signals: self.signals(), length: self.resolution.length, lineWidth: self.lineWidth, signalSpacing: self.signalSpacing)
//            .fill(self.fill)
//            .drawingGroup()
//    }
//    
//    internal struct _Graph: Shape {
//    
//        var signals: [FFT.Signal]
//        let length: UInt
//        let lineWidth: CGFloat
//        var signalSpacing: CGFloat
//        
//        func path(in frame: CGRect) -> Path {
//            
//            var signals: [FFT.Signal] { self.signals }
//            let phase: (DSPFloat) -> CGFloat = { time in
//                (CGFloat(time) * frame.height) / 2
//            }
//            let incrementX = (frame.width - self.signalSpacing * CGFloat(signals.count)) / CGFloat(signals.count * Int(self.length))
//            
//
//            var path = Path()
//
//            signals.enumerated().forEach { signal in // signal.element: FFT.Signal
//                
//                let offsetX = CGFloat(signal.offset) * self.signalSpacing
//                
//                signal.element.enumerated().forEach { sample in // sample.element: DSPFloat
//
//                    guard sample.offset != .zero else {
//                        print("here")
//                        // Putting this here to prevent unnecessary calculations
//                        path.move(to: CGPoint(x: offsetX, y: frame.midY + phase(sample.element)))
//                        return
//                    }
//                    
//                    let x = (CGFloat(sample.offset) * incrementX) + offsetX
//                    let y = frame.midY + phase(sample.element)
//
//                    print(frame.size.width, frame.size.height)
//                    
//                    path.addLine(to: CGPoint(x: x, y: y))
//                }
//                
//            }
//
//            return path
//                .strokedPath(StrokeStyle(lineWidth: self.lineWidth, lineCap: .round))
//        }
//        
//        var animatableData: [FFT.Signal] {
//            get { self.signals }
//            set { self.signals = newValue }
//        }
//        
//    }
//}
