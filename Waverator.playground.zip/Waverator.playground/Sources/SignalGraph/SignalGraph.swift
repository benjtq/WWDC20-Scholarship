import SwiftUI

public struct SignalGraph<Fill: ShapeStyle> {
    
    @Binding var signal: FFT.Signal
    private let width: CGFloat
    private let height: CGFloat
    private let fill: Fill
    private let lineWidth: CGFloat
    
    public init(
        signal: Binding<FFT.Signal>,
        width: CGFloat, height: CGFloat,
        fill: Fill, lineWidth: CGFloat = 4) {
    
        self._signal = signal
        self.width = width
        self.height = height
        self.fill = fill
        self.lineWidth = lineWidth
        
    }
    
    
    
}

extension SignalGraph: View {
    
    public var body: some View {
        _Graph(
            signal: self.$signal,
            width: self.width, height: self.height,
            fill: self.fill, lineWidth: self.lineWidth
        ).animation(.default)
    }
    
    internal struct _Graph {
    
        @Binding var signal: FFT.Signal
        let width: CGFloat
        let height: CGFloat
        let fill: Fill
        let lineWidth: CGFloat
        
    }
}

extension SignalGraph._Graph: View, Animatable {
        
    var body: some View {
        
        GeometryReader<AnyView> { frame in
            
            var signal: FFT.Signal { self.signal }
            let phase: (DSPFloat) -> CGFloat = { time in
                CGFloat(time) * self.height / 4
            }
            let incrementX = self.width / CGFloat(signal.count - 1)
            
            var path = Path()

            signal.enumerated().forEach { sample in

                guard sample.offset != .zero else {
                    // Putting this here to prevent unnecessary calculations
                    path.move(to: CGPoint(x: .zero, y: self.height / 4 + phase(sample.element)))
                    return
                }
                
                let x = CGFloat(sample.offset) * incrementX
                let y = self.height / 4 + phase(sample.element)
                path.addLine(to: CGPoint(x: x, y: y))
            }

            return AnyView(ZStack {
                path.fill(Color.accentColor.opacity(0.5))
                path.strokedPath(StrokeStyle(lineWidth: self.lineWidth, lineCap: .round))
                    .fill(self.fill)
            }.animation(.default))
        }
    }
        
    var animatableData: FFT.Signal {
        get { self.signal }
        set { self.signal = newValue }
    }
}
