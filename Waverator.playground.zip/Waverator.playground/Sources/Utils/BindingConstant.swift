import SwiftUI

extension Binding {
    public init(constant: Value) {
        self.init(get: { constant }, set: { _ in })
    }
}
