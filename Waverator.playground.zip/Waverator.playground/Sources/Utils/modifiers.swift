import SwiftUI

extension View {
    func blockStyle(_ borderColor: Color, cornerRadius: CGFloat = 11) -> some View {
        GeometryReader { geo in
            ZStack {
                self.cornerRadius(cornerRadius)
                    .frame(width: geo.size.width, height: geo.size.height)
                self
                    .cornerRadius(cornerRadius)
                    .overlay(RoundedRectangle(cornerRadius: cornerRadius)
                        .stroke(borderColor, lineWidth: 2)
                    ).frame(width: geo.size.width - 2, height: geo.size.width - 2)
            }
        }
    }
}
