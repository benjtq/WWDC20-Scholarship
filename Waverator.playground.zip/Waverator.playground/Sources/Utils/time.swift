import Darwin

func eval_time<Expression>(_ process: () -> Expression) -> (result: Expression, time: Double) {
    
    let before = clock()
    let result = process()
    
    let duration = Double(clock() - before) / Double(CLOCKS_PER_SEC)
    return (result, duration)
}

func time(_ process: () -> Void) -> Double {
    eval_time { () -> Int in
        process()
        return 1
    }.time
}
