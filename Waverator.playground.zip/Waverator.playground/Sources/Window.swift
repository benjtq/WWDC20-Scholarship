import AppKit
import SwiftUI

public struct Window<Content: View>: View {
    
    let content: Content
    @Environment(\.colorScheme) var colourScheme: ColorScheme
    
    public init(_ content: Content) {
        self.content = content
    }
    
    public var body: some View {
        ZStack(alignment: .top) {
//            Color.secondaryBackground(mode: self.colourScheme)
            self.content.padding(15)
        }
    }
}
